




$('img').click(function() {
    $(this).hide();
    console.log('hello');
});



$('#restoreBtn').click(function() {

    $('img').show();
});











